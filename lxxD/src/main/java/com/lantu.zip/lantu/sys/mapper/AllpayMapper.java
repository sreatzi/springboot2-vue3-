package com.lantu.sys.mapper;

import com.lantu.sys.entity.Allpay;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author sreat
 * @since 2023-12-18
 */
public interface AllpayMapper extends BaseMapper<Allpay> {

}
